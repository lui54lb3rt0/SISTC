<?php include("header.html");?>

<h1> Homepage </h1>
<!-- Editar a gosto. -->

<?php include("footer.html");?>
